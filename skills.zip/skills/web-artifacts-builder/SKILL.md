---
name: web-artifacts-builder
description: Suite of tools for creating elaborate, multi-component HTML artifacts using modern frontend web technologies (React, Tailwind CSS, shadcn/ui). Use for complex web UIs requiring state management, routing, or shadcn/ui components — not for simple single-file HTML/JSX artifacts (use frontend-design skill for those).
license: Complete terms in LICENSE.txt
---

# Web Artifacts Builder

To build powerful frontend artifacts, follow these steps:
1. Initialize the frontend repo using `scripts/init-artifact.sh` via `run_code(action="run_shell")`
2. Develop your artifact by editing the generated code via `run_code(action="run_shell")`
3. Bundle all code into a single HTML file using `scripts/bundle-artifact.sh` via `run_code(action="run_shell")`
4. Send the bundled HTML to Discord via `send_files`
5. (Optional) Test the artifact

**Stack**: React 18 + TypeScript + Vite + Parcel (bundling) + Tailwind CSS + shadcn/ui

## Design & Style Guidelines

VERY IMPORTANT: To avoid what is often referred to as "AI slop", avoid using excessive centered layouts, purple gradients, uniform rounded corners, and Inter font.

## Quick Start

### Step 1: Initialize Project

Run the initialization script via `run_code(action="run_shell")`:
```bash
bash scripts/init-artifact.sh <project-name>
cd <project-name>
```

This creates a fully configured project with:
- ✅ React + TypeScript (via Vite)
- ✅ Tailwind CSS 3.4.1 with shadcn/ui theming system
- ✅ Path aliases (`@/`) configured
- ✅ 40+ shadcn/ui components pre-installed
- ✅ All Radix UI dependencies included
- ✅ Parcel configured for bundling (via .parcelrc)
- ✅ Node 18+ compatibility (auto-detects and pins Vite version)

### Step 2: Develop Your Artifact

Edit the generated files via shell commands in `run_code(action="run_shell")`. See **Common Development Tasks** below for guidance.

### Step 3: Bundle to Single HTML File

Bundle the React app into a single self-contained HTML file:
```bash
bash scripts/bundle-artifact.sh
# Then copy the result to OUTPUT_DIR so it gets sent to Discord
cp bundle.html "$OUTPUT_DIR/bundle.html"
```

Run both commands together in one `run_code(action="run_shell", send_output=true)` call.

**What the script does**:
- Installs bundling dependencies (parcel, @parcel/config-default, parcel-resolver-tspaths, html-inline)
- Creates `.parcelrc` config with path alias support
- Builds with Parcel (no source maps)
- Inlines all assets into single HTML using html-inline

### Step 4: Share with Sensei

The `bundle.html` in `OUTPUT_DIR` is automatically sent to Discord by `send_output=true`. A preview link is auto-appended to the message.

Alternatively, if the file already exists in temp storage (e.g. from a prior step), use `send_files([file_id])`.

### Step 5: Testing/Visualizing the Artifact (Optional)

Only perform if necessary or requested. Avoid testing upfront as it adds latency.

## Reference

- **shadcn/ui components**: https://ui.shadcn.com/docs/components